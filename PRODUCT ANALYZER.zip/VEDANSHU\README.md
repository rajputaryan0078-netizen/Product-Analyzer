# VEDANSHU — Product Packet Analyser

> AI-powered food label analysis platform — Minor Project Submission (100% Complete)

---

## What It Does

Upload a photo of any packaged food product and VEDANSHU will:

1. **OCR** — Extract text using Tesseract (multi-PSM, LSTM engine)
2. **Parse** — Extract product name, brand, MRP, dates, ingredients, serving size
3. **Nutrition** — Detect 11 nutrients and benchmark them against NHS/FSSAI per-100g guidelines
4. **Health Score** — Compute a real 0–100 weighted health score (Grade A–D) using NHS traffic-light thresholds
5. **Risk Alerts** — Quantitative nutrition alerts (HIGH/MODERATE/OK) + ingredient flags (10 categories)
6. **Allergen Detection** — Scan 13 allergen categories (Gluten, Dairy, Peanuts, Tree Nuts, Soy, Eggs, Fish, Crustaceans, Sesame, Mustard, Sulphites, Celery, Molluscs)
7. **Export** — Download a formatted PDF report or CSV spreadsheet
8. **Scan History** — Session log of all past analyses with scores and alert summaries

---

## Project Structure

```
VEDANSHU/
├── app.py                    ← Streamlit entry point (4-screen router)
├── requirements.txt
├── .streamlit/
│   └── config.toml           ← Dark theme, server config
│
├── backend/                  ← All business logic
│   ├── __init__.py
│   ├── allergen_engine.py    ← 13 allergen categories keyword detection
│   ├── export_engine.py      ← PDF (reportlab) + CSV download generation
│   ├── extractor.py          ← Regex field & nutrition extraction (19 fields)
│   ├── health_score.py       ← Real 0–100 weighted health score formula
│   ├── image_utils.py        ← Image validation + 6-step OpenCV preprocessing
│   ├── nutrition_rules.py    ← NHS/FSSAI threshold evaluations
│   ├── ocr_utils.py          ← Tesseract multi-PSM OCR + text cleaning
│   ├── risk_engine.py        ← Quantitative alerts + ingredient flag engine
│   └── scan_history.py       ← Session-scoped scan log manager
│
└── frontend/                 ← UI components and styles
    ├── __init__.py
    ├── components.py         ← Health score panel, allergen panel, history panel
    └── styles.css            ← Unified CSS design system (Space Grotesk, JetBrains Mono)
```

---

## Screens

| Screen    | Description |
|-----------|-------------|
| Landing   | Hero, 6 feature cards, how-it-works, health score preview |
| Scanner   | Holographic upload chamber with OCR pipeline |
| Results   | Full dashboard: score, nutrients, risk alerts, allergens, export |
| History   | Session log of all scans with grades and alert summaries |

---

## Health Score Formula

Six nutrients scored on a 0–100 scale, weighted sum = final score:

| Nutrient | Weight | Direction | OK threshold | HIGH threshold |
|---|---|---|---|---|
| Sugar | 20% | Penalty | ≤ 5g | ≥ 22.5g |
| Saturated Fat | 20% | Penalty | ≤ 1.5g | ≥ 5g |
| Trans Fat | 15% | Penalty | ≤ 0.2g | ≥ 2g |
| Sodium | 15% | Penalty | ≤ 300mg | ≥ 600mg |
| Protein | 15% | Reward | ≤ 5g | ≥ 10g |
| Dietary Fibre | 15% | Reward | ≤ 3g | ≥ 6g |

Grade bands: **A** (≥75) · **B** (≥55) · **C** (≥35) · **D** (<35)

---

## Installation

```bash
pip install -r requirements.txt
```

### Tesseract OCR (required for real image analysis)

1. Download: https://github.com/UB-Mannheim/tesseract/wiki
2. Install to `C:\Program Files\Tesseract-OCR\`
3. Restart terminal

> **No Tesseract?** Use "Sample Demo Packet" on the landing page — the full pipeline runs on sample data.

---

## Running the App

```bash
streamlit run app.py
```

---

## Reference Thresholds

- **NHS UK** traffic-light labelling (per 100g) — Sugar, Fat, Saturated Fat, Salt, Sodium
- **FSSAI** Draft Regulations 2022 — Trans Fat (≤ 2g per 100g)
- **WHO** recommendations — Sodium intake, Trans Fat elimination
- **ICMR** — Added sugar limits

---

## Disclaimer

All outputs are for **informational and educational purposes only**.  
They are not a medical diagnosis, dietary prescription, or safety verdict.  
Always verify information on the physical product label.  
Consult a registered dietitian for personal dietary advice.

---

## Tech Stack

| Layer | Technology |
|---|---|
| UI Framework | Streamlit ≥ 1.30 |
| OCR Engine | Tesseract 5.x via pytesseract |
| Image Processing | OpenCV 4.x, Pillow |
| PDF Export | ReportLab 4.x / 5.x |
| Data | pandas, numpy |
| Language | Python 3.9+ |

---

*VEDANSHU — Product Packet Analyser | Minor Project | Not medical advice*
